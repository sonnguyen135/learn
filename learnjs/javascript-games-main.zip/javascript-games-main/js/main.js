// null is like filled with air
// undefined is like vacuume

// evaluate to false -> 0, null, '', undefined

// Numbers
// NaN is Not a Number

// String
// define string using -> '', "", ``
// instance methods
// 1. concat
// 2. includes
// 3. toLowerCase
// 4. toUpperCase
// 5. endsWith
// 6. indexOf
// 7. trim
// 8. startsWith
let statement = `There are "eight planets" in the \`solar system\` and 'earth' is our home`;
let planet = "   Earth   ";
console.log(statement.startsWith("T"));
