// parameters
// it is function declaration

// function calculate(func, ...num) {
//   return func(num);
// }

// const multiply = function (numbers) {
//   let result = 1;
//   for (let i = 0; i < numbers.length; i++) {
//     result = result * numbers[i];
//   }
//   return result;
// };

// const sum = function (numbers) {
//   let result = 0;
//   for (let i = 0; i < numbers.length; i++) {
//     result = result + numbers[i];
//   }
//   return result;
// };

// console.log(calculate(sum, 4, 6, 10, 4, 5, 6, 4, 3));
// console.log(calculate(multiply, 2, 3, 4, 5));

// // function statement
// const add = function (a, b) {
//   const result = a + b;
//   return result;
// };
