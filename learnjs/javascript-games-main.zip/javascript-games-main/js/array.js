let planets = [
  "Mercury",
  "Venus",
  "Earth",
  "Mars",
  "Jupiter",
  "Saturn",
  "Uranus",
  "Naptune",
];
// let jovians = planets.slice(4, 8);
// let terrestrial = planets.slice(0, 4);
// planets.push("Pluto");
// planets.pop();
// planets.unshift("Mercury");
// planets.shift();
// planets.splice(planets.indexOf("Jupiter"), 1);
// console.log(terrestrial.concat(jovians).join(":"));
